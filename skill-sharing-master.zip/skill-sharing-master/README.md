#Skill Sharing website.
Eloquent Javascript Chapter 21 project.


This is a skill sharing web app where users can submit talk proposals as well as enter comments for other people's proposal. The server provides the talk data, which includes the title and all the comments.

In this project I learned about long polling techniques with Node, URL handling and http request routing.
